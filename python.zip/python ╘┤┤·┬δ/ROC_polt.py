import pandas as pd
import shap
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve as ROC
from sklearn.metrics import roc_auc_score, recall_score, classification_report, confusion_matrix
from model import model_GBDT, model_XGB, model_adaboost, model_dt, model_lr, model_lgb, model_gnb, model_mlp, model_randomforest, model_svc,model_lda
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier

# 读取数据
data = pd.read_csv('./data_befilled_0416.csv')

X = data.iloc[:, :-1]  #取出特征X
y = data.iloc[:, -1]  #取出Y
train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=0)

print('------------全量数据，训练集及测试集情况（test_size=0.3)---------------------')
print('全量数据集：', X.shape, y.shape)
print('训练集：', train_X.shape, train_y.shape)
print('测试集：', test_X.shape, test_y.shape)
train_X.to_csv('训练集_x_train_0416.csv', index=False, encoding='utf_8_sig')
train_y.to_csv('训练集_y_train_0416.csv', index=False, encoding='utf_8_sig')
test_X.to_csv('测试集_x_test_0416.csv', index=False, encoding='utf_8_sig')
test_y.to_csv('测试集_y_test_0416.csv', index=False, encoding='utf_8_sig')

print('------------------------开始建模-----------------------------------------')
pred_y_GBDT, cm_GBDT, score_GBDT, recall_GBDT, auc_GBDT, pred_y_score_GBDT = model_GBDT(train_X, test_X, train_y, test_y)
pred_y_XGB, cm_XBG, score_XGB, recall_XGB, auc_XGB, pred_y_score_XGB = model_XGB(train_X, test_X, train_y, test_y)
pred_y_ADB, cm_ADB, score_ADB, recall_ADB, auc_ADB, pred_y_score_ADB = model_adaboost(train_X, test_X, train_y, test_y)
pred_y_DT, cm_DT, score_DT, recall_DT, auc_DT, pred_y_score_DT = model_dt(train_X, test_X, train_y, test_y)
pred_y_LR, cm_LR, score_LR, recall_LR, auc_LR, pred_y_score_LR = model_lr(train_X, test_X, train_y, test_y)
pred_y_LGB, cm_LGB, score_LGB, recall_LGB, auc_LGB, pred_y_score_LGB = model_lgb(train_X, test_X, train_y, test_y)
pred_y_GNB, cm_GNB, score_GNB, recall_GNB, auc_GNB, pred_y_score_GNB = model_gnb(train_X, test_X, train_y, test_y)
pred_y_MLP, cm_MLP, score_MLP, recall_MLP, auc_MLP, pred_y_score_MLP = model_mlp(train_X, test_X, train_y, test_y)
pred_y_RF, cm_RF, score_RF, recall_RF, auc_RF, pred_y_score_RF = model_randomforest(train_X, test_X, train_y, test_y)
pred_y_SVC, cm_SVC, score_SVC, recall_SVC, auc_SVC, pred_y_score_SVC = model_svc(X, train_X, test_X, train_y, test_y)
pred_y_LDA, cm_LDA, score_LDA, recall_LDA, auc_LDA, pred_y_score_LDA = model_lda(train_X, test_X, train_y, test_y)


FPR_GBDT, Recall_GBDT, thresholds_GBDT = ROC(test_y, pred_y_score_GBDT)
area_GBDT = roc_auc_score(test_y, pred_y_score_GBDT)
FPR_XGB, Recall_XGB, thresholds_XGB = ROC(test_y, pred_y_score_XGB)
area_XGB = roc_auc_score(test_y, pred_y_score_XGB)
FPR_ADB, Recall_ADB, thresholds_ADB = ROC(test_y, pred_y_score_ADB)
area_ADB = roc_auc_score(test_y, pred_y_score_ADB)
FPR_DT, Recall_DT, thresholds_DT = ROC(test_y, pred_y_score_DT)
area_DT = roc_auc_score(test_y, pred_y_score_DT)
FPR_LR, Recall_LR, thresholds_LR = ROC(test_y, pred_y_score_LR)
area_LR = roc_auc_score(test_y, pred_y_score_LR)
FPR_LGB, Recall_LGB, thresholds_LGB = ROC(test_y, pred_y_score_LGB)
area_LGB = roc_auc_score(test_y, pred_y_score_LGB)
FPR_GNB, Recall_GNB, thresholds_GNB = ROC(test_y, pred_y_score_GNB)
area_GNB = roc_auc_score(test_y, pred_y_score_GNB)
FPR_MLP, Recall_MLP, thresholds_MLP = ROC(test_y, pred_y_score_MLP)
area_MLP = roc_auc_score(test_y, pred_y_score_MLP)
FPR_RF, Recall_RF, thresholds_RF = ROC(test_y, pred_y_score_RF)
area_RF = roc_auc_score(test_y, pred_y_score_RF)
FPR_SVC, Recall_SVC, thresholds_SVC = ROC(test_y, pred_y_score_SVC)
area_SVC = roc_auc_score(test_y, pred_y_score_SVC)
FPR_LDA, Recall_LDA, thresholds_LDA = ROC(test_y, pred_y_score_LDA)
area_LDA = roc_auc_score(test_y, pred_y_score_LDA)

plt.figure()

plt.plot(FPR_GBDT, Recall_GBDT, color='red', label='GBDT')
plt.plot(FPR_XGB, Recall_XGB, color='blue', label='XGBoost')
plt.plot(FPR_ADB, Recall_ADB, color='green', label='AdaBoost')
plt.plot(FPR_DT, Recall_DT, color='yellow', label='DecisionTree')
plt.plot(FPR_LR, Recall_LR, color='brown', label='LogisticRegression')
plt.plot(FPR_LGB, Recall_LGB, color='pink', label='LightGBM')
plt.plot(FPR_GNB, Recall_GNB, color='purple', label='GaussianNB')
plt.plot(FPR_MLP, Recall_MLP, color='grey', label='MLP')
plt.plot(FPR_RF, Recall_RF, color='gold', label='Random Forest')
plt.plot(FPR_SVC, Recall_SVC, color='silver', label='SVC')
plt.plot(FPR_LDA, Recall_LDA, color='orchid', label='LDA')

plt.xlim([-0.05, 1.05])
plt.ylim([-0.05, 1.05])

ax = plt.gca()
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')

plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic', fontdict={'size': 13, 'color': 'black'})
plt.legend(loc="lower right")
plt.show()

# Adaboost建模和SHAP值分析
clf = AdaBoostClassifier(DecisionTreeClassifier(max_depth=2, min_samples_split=20, min_samples_leaf=5, random_state=10),
                         n_estimators=300,
                         learning_rate=1,
                         random_state=10).fit(train_X, train_y)

#clf = RandomForestClassifier(random_state=100).fit(train_X, train_y)

# SHAP分析
explainer = shap.TreeExplainer(clf)
shap.initjs()
shap_values = explainer.shap_values(test_X)

#保存SHAP数据
df_shap_0 = pd.DataFrame(shap_values[0])
df_shap_1 = pd.DataFrame(shap_values[1])
df_shap_0.to_csv('df_shap_0.csv', index=False, encoding='utf_8_sig')
df_shap_1.to_csv('df_shap_1.csv', index=False, encoding='utf_8_sig')

#SHAP小提琴图
fig, ax1 = plt.subplots()

shap.summary_plot(shap_values[1], test_X, show=False)
ax1.set_xlabel('SHAP value (impact on model output)',
               fontdict={'family': 'Times New Roman', 'fontsize': 15, 'fontweight': 'bold'}
               )
ax1.set_ylabel('Features',
               fontdict={'family': 'Times New Roman', 'fontsize': 15, 'fontweight': 'bold'}
               )
plt.show()

#SHAP柱状图
fig, ax0 = plt.subplots()

shap.summary_plot(shap_values[1], test_X, plot_type="bar", show=False)
ax0.set_xlabel('Mean(|SHAP|) value of each feature',
               fontdict={'family': 'Times New Roman', 'fontsize': 18, 'fontweight': 'bold'}
               )
ax0.set_ylabel('Features',
               fontdict={'family': 'Times New Roman', 'fontsize': 18, 'fontweight': 'bold'}
               )
ax0.grid(axis='x')
plt.show()
