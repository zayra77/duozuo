import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import GridSearchCV, train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor



# 读取数据
data = pd.read_excel('./data_0416.xlsx')
#print(data.info())

X = data.iloc[:, :-1]
y = data.iloc[:, -1]
#print(X.shape, y.shape)

# 填补缺失值

df = X
fillc = df.loc[:, 'α2-AP']
df = pd.concat([df.loc[:, df.columns != 'α2-AP'], pd.DataFrame(y)], axis=1)


Ytrain = fillc[fillc.notnull()]
Ytest = fillc[fillc.isnull()]

Xtrain = df.iloc[Ytrain.index, :]
Xtest = df.iloc[Ytest.index, :]

rfc = RandomForestRegressor(n_estimators=100)
rfc = rfc.fit(Xtrain, Ytrain)
Ypredict = rfc.predict(Xtest)

X.loc[X.loc[:, 'α2-AP'].isnull(), 'α2-AP'] = Ypredict

data = pd.concat([X, pd.DataFrame(y)], axis=1)

#print(data.info())
data.to_csv('data_befilled_0416.csv', index=False, encoding='utf_8_sig')





