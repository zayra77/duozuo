import pandas as pd
import numpy as np
import sklearn
import sys
from sklearn.model_selection import GridSearchCV, train_test_split, cross_val_score
from sklearn.metrics import roc_auc_score, recall_score, classification_report, confusion_matrix
from sklearn.metrics import roc_curve as ROC
from sklearn.ensemble import GradientBoostingClassifier, AdaBoostClassifier, RandomForestClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.preprocessing import StandardScaler

print("The version of Sklearn is " + sklearn.__version__)
print("The version of Python is "+ sys.version)


def print_model_score(clf, pred_y, pred_y_score, score, recall, cm, auc):

    print("-------------------------测试集预测结果------------------------------")
    print(pred_y)
    print("-------------------------测试集预测结果分数------------------------------")
    print(pred_y_score)
    print("-------------------------testing accuracy------------------------------")
    print(score)
    print("-------------------------recall------------------------------")
    print(recall)
    print("-------------------------confusion matrix------------------------------")
    print(cm)
    print("----------------------auc-------------------------------------")
    print(auc)
    print("--------------------------------------------------------------")


def model_score(clf, test_X, test_y):

    pred_y = clf.predict(test_X)
    pred_y_score = clf.predict_proba(test_X)[:, 1]
    score = clf.score(test_X, test_y)
    recall = recall_score(test_y, pred_y)
    auc = roc_auc_score(test_y, pred_y_score)
    cm = confusion_matrix(test_y, pred_y)
    print_model_score(clf, pred_y, pred_y_score, score, recall, cm, auc)

    return(pred_y, cm, score, recall, auc, pred_y_score)


def cross_val(clf, train_X, train_y):
    print("-------------------------------------------------------")
    print(clf)
    scores = cross_val_score(clf, train_X, train_y, cv=3)
    score = scores.mean()
    print("Cross-Validation Results :")
    print(scores)
    print("The average is " + str(score))


def model_GBDT(train_X, test_X, train_y, test_y):

    params = {'max_depth': 1,
              'learning_rate': 0.05,
              'n_estimators': 150,
              'random_state': 100}
    clf = GradientBoostingClassifier(**params)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return(model_score(clf, test_X, test_y))


def model_XGB(train_X, test_X, train_y, test_y):

    clf = XGBClassifier(n_estimators=100, learning_rate=0.05, max_depth=1, random_state=10)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return (model_score(clf, test_X, test_y))


def model_adaboost(train_X, test_X, train_y, test_y):

    clf = AdaBoostClassifier(
        DecisionTreeClassifier(max_depth=2, min_samples_split=20, min_samples_leaf=5, random_state=10),
        n_estimators=300,
        learning_rate=1,
        random_state=10)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return (model_score(clf, test_X, test_y))


def model_dt(train_X, test_X, train_y, test_y):

    clf = DecisionTreeClassifier(criterion='gini', max_depth=4, random_state=100)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return (model_score(clf, test_X, test_y))


def model_lr(train_X, test_X, train_y, test_y):

    clf = LogisticRegression(random_state=100)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return (model_score(clf, test_X, test_y))


def model_lgb(train_X, test_X, train_y, test_y):

    clf = LGBMClassifier(n_estimators=120, learning_rate=0.2, num_leaves=10,random_state=100)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return (model_score(clf, test_X, test_y))


def model_gnb(train_X, test_X, train_y, test_y):

    clf = GaussianNB()
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return (model_score(clf, test_X, test_y))


def model_mlp(train_X, test_X, train_y, test_y):

    clf = MLPClassifier(hidden_layer_sizes=(100, 30), solver='lbfgs', random_state=100)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return (model_score(clf, test_X, test_y))


def model_randomforest(train_X, test_X, train_y, test_y):

    clf = RandomForestClassifier(random_state=100)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return(model_score(clf, test_X, test_y))


def model_lda(train_X, test_X, train_y, test_y):

    clf = LDA()
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    return (model_score(clf, test_X, test_y))


def model_svc(X, train_X, test_X, train_y, test_y):

    scaler = StandardScaler()
    scaler.fit(X)
    train_X = scaler.transform(train_X)
    test_X = scaler.transform(test_X)

    clf = SVC(kernel='rbf',random_state=100)
    cross_val(clf, train_X, train_y)
    clf = clf.fit(train_X, train_y)
    pred_y = clf.predict(test_X)
    pred_y_score = clf.decision_function(test_X)
    score = clf.score(test_X, test_y)
    recall = recall_score(test_y, pred_y)
    auc = roc_auc_score(test_y, clf.decision_function(test_X))
    cm = confusion_matrix(test_y, pred_y)
    print_model_score(clf, pred_y, pred_y_score, score, recall, cm, auc)
    return (pred_y, cm, score, recall, auc, pred_y_score)

