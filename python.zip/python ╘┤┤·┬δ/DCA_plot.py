import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from plot_fun import calculate_net_benefit_model, calculate_net_benefit_all, plot_DCA
from model import model_GBDT, model_XGB, model_adaboost, model_dt, model_lr, model_lgb, model_gnb, model_mlp, model_randomforest, model_svc,model_lda

# 读取数据
data = pd.read_csv('./data_befilled_0416.csv')

X = data.iloc[:, :-1]  #取出特征X
y = data.iloc[:, -1]  #取出Y
train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.3, random_state=0)

print('------------全量数据，训练集及测试集情况（test_size=0.3)---------------------')
print('全量数据集：', X.shape, y.shape)
print('训练集：', train_X.shape, train_y.shape)
print('测试集：', test_X.shape, test_y.shape)
train_X.to_csv('训练集_x_train.csv', index=False, encoding='utf_8_sig')
train_y.to_csv('训练集_y_train.csv', index=False, encoding='utf_8_sig')
test_X.to_csv('测试集_x_test.csv', index=False, encoding='utf_8_sig')
test_y.to_csv('测试集_y_test.csv', index=False, encoding='utf_8_sig')

print('------------------------开始建模-----------------------------------------')
pred_y_GBDT, cm_GBDT, score_GBDT, recall_GBDT, auc_GBDT, pred_y_score_GBDT = model_GBDT(train_X, test_X, train_y, test_y)
pred_y_XGB, cm_XBG, score_XGB, recall_XGB, auc_XGB, pred_y_score_XGB = model_XGB(train_X, test_X, train_y, test_y)
pred_y_ADB, cm_ADB, score_ADB, recall_ADB, auc_ADB, pred_y_score_ADB = model_adaboost(train_X, test_X, train_y, test_y)
pred_y_DT, cm_DT, score_DT, recall_DT, auc_DT, pred_y_score_DT = model_dt(train_X, test_X, train_y, test_y)
pred_y_LR, cm_LR, score_LR, recall_LR, auc_LR, pred_y_score_LR = model_lr(train_X, test_X, train_y, test_y)
pred_y_LGB, cm_LGB, score_LGB, recall_LGB, auc_LGB, pred_y_score_LGB = model_lgb(train_X, test_X, train_y, test_y)
pred_y_GNB, cm_GNB, score_GNB, recall_GNB, auc_GNB, pred_y_score_GNB = model_gnb(train_X, test_X, train_y, test_y)
pred_y_MLP, cm_MLP, score_MLP, recall_MLP, auc_MLP, pred_y_score_MLP = model_mlp(train_X, test_X, train_y, test_y)
pred_y_RF, cm_RF, score_RF, recall_RF, auc_RF, pred_y_score_RF = model_randomforest(train_X, test_X, train_y, test_y)
pred_y_SVC, cm_SVC, score_SVC, recall_SVC, auc_SVC, pred_y_score_SVC = model_svc(X, train_X, test_X, train_y, test_y)
pred_y_LDA, cm_LDA, score_LDA, recall_LDA, auc_LDA, pred_y_score_LDA = model_lda(train_X, test_X, train_y, test_y)

thresh_group = np.arange(0, 1, 0.01)
print('-----------------net_benefit_model_GBDT----------------------')
net_benefit_model_GBDT = calculate_net_benefit_model(thresh_group, pred_y_score_GBDT, test_y)
print('-----------------net_benefit_model_XGBoost----------------------')
net_benefit_model_XGB = calculate_net_benefit_model(thresh_group, pred_y_score_XGB, test_y)
print('-----------------net_benefit_model_AdaBoost----------------------')
net_benefit_model_ADB = calculate_net_benefit_model(thresh_group, pred_y_score_ADB, test_y)
print('-----------------net_benefit_model_Decision Tree----------------------')
net_benefit_model_DT = calculate_net_benefit_model(thresh_group, pred_y_score_DT, test_y)
print('-----------------net_benefit_model_Logistic Regression----------------------')
net_benefit_model_LR = calculate_net_benefit_model(thresh_group, pred_y_score_LR, test_y)
print('-----------------net_benefit_model_LightGBM----------------------')
net_benefit_model_LGB = calculate_net_benefit_model(thresh_group, pred_y_score_LGB, test_y)
print('-----------------net_benefit_model_GaussianNB----------------------')
net_benefit_model_GNB = calculate_net_benefit_model(thresh_group, pred_y_score_GNB, test_y)
print('-----------------net_benefit_model_MLP----------------------')
net_benefit_model_MLP = calculate_net_benefit_model(thresh_group, pred_y_score_MLP, test_y)
print('-----------------net_benefit_model_Random Forest----------------------')
net_benefit_model_RF = calculate_net_benefit_model(thresh_group, pred_y_score_RF, test_y)
print('-----------------net_benefit_model_SVC----------------------')
net_benefit_model_SVC = calculate_net_benefit_model(thresh_group, pred_y_score_SVC, test_y)
print('-----------------net_benefit_model_LDA----------------------')
net_benefit_model_LDA = calculate_net_benefit_model(thresh_group, pred_y_score_LDA, test_y)

net_benefit_all = calculate_net_benefit_all(thresh_group, test_y)
fig, ax = plt.subplots()
ax.plot(thresh_group, net_benefit_model_GBDT, color='red', label='GBDT')
ax.plot(thresh_group, net_benefit_model_XGB, color='blue', label='XGBoost')
ax.plot(thresh_group, net_benefit_model_ADB, color='green', label='AdaBoost')
ax.plot(thresh_group, net_benefit_model_DT, color='yellow', label='Decision Tree')
ax.plot(thresh_group, net_benefit_model_LR, color='brown', label='Logistic Regression')
ax.plot(thresh_group, net_benefit_model_LGB, color='pink', label='LightGBM')
ax.plot(thresh_group, net_benefit_model_GNB, color='purple', label='GaussianNB')
ax.plot(thresh_group, net_benefit_model_MLP, color='grey', label='MLP')
ax.plot(thresh_group, net_benefit_model_RF, color='gold', label='Random Forest')
ax.plot(thresh_group, net_benefit_model_SVC, color='silver', label='SVC')
ax.plot(thresh_group, net_benefit_model_LDA, color='orchid', label='LDA')
ax.plot(thresh_group, net_benefit_all, color='black', label='Treat all')
ax.plot((0, 1), (0, 0), color='black', linestyle=':', label='Treat none')

ax.set_xlim(0, 1)
ax.set_ylim(net_benefit_model_GBDT.min()-0.15, net_benefit_model_GBDT.max()+0.15)#adjustify the y axis limitation
ax.set_xlabel(
    xlabel ='Threshold Probability',
    fontdict={'family': 'Times New Roman', 'fontsize':15}
    )
ax.set_ylabel(
    ylabel ='Net Benefit',
    fontdict={'family': 'Times New Roman', 'fontsize':15}
    )
ax.grid('major')
ax.spines['right'].set_color((0.8, 0.8, 0.8))
ax.spines['top'].set_color((0.8, 0.8, 0.8))
#ax.legend(loc='upper right')
plt.legend(loc='lower left')
plt.show()


